To push changes:
    - run `npm run build`
    - then push changes through github desktop 

To run locally:
    - 'npm run build'
    - go to `file:///C:/Users/brend/Desktop/cubingProject/brendonmay.github.io/LegionCalculator/index.html` in the browser 